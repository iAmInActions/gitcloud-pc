-- backward comp
return require"smq.broker"
